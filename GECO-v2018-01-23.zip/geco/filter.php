<?php

include 'vars.php'; // récupère les variables

$mouvement=array_keys($mouvements_libelle);
unset($mouvement[count($mouvement)-1]);

// Chargement des structure
$structure = json_decode($mouvements_structure,true);
$id=$_COOKIE['id'];

$share='';
if(isset($_GET['share'])){
	$share=$_GET['share'];
}

if($share==''){
	$path='upload/'.$id.'/';
	$GET='';
}else{
	$path='share/';
	$GET='?share='.$share;
}
$analyse = file($path.'analyse'.$share.'.txt',FILE_SKIP_EMPTY_LINES);

if(isset($_GET['exact'])){
	$exact=$_GET['exact'];
	$all=$_GET['all'];
	$alone=$_GET['alone'];
}
if(isset($_GET['value'])){
	$value=strtoupper($_GET['value']);
	switch (strlen($value)) {
		case 2:
			$position=(in_array($value,$mouvement)) ? 43 : 164;
			break;
		case 3:
			$position=(is_numeric(substr($value,0,1))) ? 43 : 164;
			break;
		case 39:
			$position=4;
			break;
		case 13:
			$position=26;
			break;
		default:
			$position=164;
	}	
	//$position=(strlen($value)==39) ? 4 : 43;
}else{
	if(substr($analyse[0],43,1)=="4"){
		$value=substr($analyse[0],43,3);
	}else{
		$value=substr($analyse[0],43,2);
	}
	$position=43;
}
//echo $value."/".$exact."/".$all."/".$alone.'/'.$share;
$datas=array();
for($i=0;$i<count($analyse);$i++){
	if($value==substr($analyse[$i],$position,strlen($value))){
		$datas[]=$analyse[$i];
	}
}
$rem_mvt='';
for($i=0;$i<count($datas);$i++){
	if(substr($datas[$i],43,1)=="4"){
		$mvt=substr($datas[$i],43,3);
	}else{
		$mvt=substr($datas[$i],43,2);
	}
	if($mvt!=$rem_mvt){
		if($rem_mvt!=''){
			echo '			</tbody>'."\n";
			echo '		</table>'."\n";
		}
		echo '		<span class="titre">MVT '.$mvt.'</span>';
		echo '		<span class="libelle">'.$mouvements_libelle[$mvt].'</span>';
		echo '		<br>'."\n";
		echo '	<input type="text" id="quickfind" style="display:none;border:none;color:#086A87">'."\n";
		echo '		<table id="quicksearch" style="width:100%;margin-bottom:15px">'."\n";
		echo '			<thead >'."\n";
		echo '			<tr>'."\n";
		echo '				<th filter="false">SI</th><th>CLEF_MVT</th><th>NOM_PRE</th><th>NUM_UTI</th><th filter="false">MVT</th>'."\n";
		for($k=0;$k<count($structure[$mvt]);$k++)
		{
			echo '				<th>'.$structure[$mvt][$k]['field'].'</th>'."\n";
		}	
		for($k=0;$k<count($structure['ZC']);$k++)
		{
			if($structure['ZC'][$k]['key']=="0"){
				echo '				<th>'.$structure['ZC'][$k]['field'].'</th>'."\n";
			}
		}	
		echo '			</tr>'."\n";
		echo '			</thead >'."\n";

		echo '			<tbody>'."\n";
		$rem_mvt=$mvt;
	}	
	$resultat=substr($datas[$i],0,1); // Récupération du code résultat
	$num_SI=substr($datas[$i],2,1); // Récupération du numéro du SI (1 ou 2)
	$offset=($num_SI=='1' ? 1 : -1); // pour colorisation de l'erreur si différence. On compare la donnée avec la ligne suivante si SI 1 et précédente si SI 2

	echo '				<tr class="res'.$resultat.'" title="Dossier '.$SI[substr($datas[$i],1,2)].' de '.trim(substr($datas[$i],161-1+4,30)).'" id="'.$mvt.$i.'">'."\n";
	echo '					<td>'.$SI[substr($datas[$i],1,2)].'</td>'."\n";
	echo '					<td>'.substr($datas[$i],4,39).'</td>'."\n";
	echo '					<td style="font-weight:bold;text-decoration:underline" onclick="filter(\''.substr($datas[$i],4,39).'\',\'\')">'.substr($datas[$i],161-1+4,30).'</td>'."\n";
	echo '					<td>'.substr($datas[$i],194-1+4,9).'</td>'."\n";
	echo '					<td>'.substr($datas[$i],40-1+4,2).'</td>'."\n";
			
	for($k=0;$k<count($structure[$mvt]);$k++){
		$compare=false;
		if($exact=='1'){ // Si mode exact
			if($resultat=='1' and substr($datas[$i],intval($structure[$mvt][$k]['position'])-1+4,intval($structure[$mvt][$k]['length']))!=substr($datas[$i+$offset],intval($structure[$mvt][$k]['position'])-1+4,intval($structure[$mvt][$k]['length']))){
				$compare=true;
			}
		}else{ // Sinon on ne colorise que les champs à comparer
			if($resultat=='1' and substr($datas[$i],intval($structure[$mvt][$k]['position'])-1+4,intval($structure[$mvt][$k]['length']))!=substr($datas[$i+$offset],intval($structure[$mvt][$k]['position'])-1+4,intval($structure[$mvt][$k]['length'])) and $structure[$mvt][$k]['compare']=="1"){
				$compare=true;
			}
		}

		if($compare){
			$color=' style="font-weight:bold;color:red"';
		}else{
			$color='';
		}
		echo '					<td'.$color.'>'.substr($datas[$i],intval($structure[$mvt][$k]['position'])-1+4,intval($structure[$mvt][$k]['length'])).'</td>'."\n";
	}	

	for($k=0;$k<count($structure['ZC']);$k++){
		if($structure['ZC'][$k]['key']=="0"){

			$compare=false;
			if($exact=='1'){ // Si mode exact
				if($resultat=='1' and substr($datas[$mvt],intval($structure['ZC'][$k]['position'])-1+4,intval($structure['ZC'][$k]['length']))!=substr($datas[$i+$offset],intval($structure['ZC'][$k]['position'])-1+4,intval($structure['ZC'][$k]['length']))){
					$compare=true;
				}
			}else{ // Sinon on ne colorise que les champs à comparer
				if($resultat=='1' and substr($datas[$i],intval($structure['ZC'][$k]['position'])-1+4,intval($structure['ZC'][$k]['length']))!=substr($datas[$i+$offset],intval($structure['ZC'][$k]['position'])-1+4,intval($structure['ZC'][$k]['length'])) and $structure['ZC'][$k]['compare']=="1"){
					$compare=true;
				}
			}

			if($compare){
				$color=' style="font-weight:bold;color:red"';
			}else{
				$color='';
			}
			if($structure['ZC'][$k]['field']=='NOM_PRE'){
				echo '					<td style="font-weight:bold;text-decoration:underline" onclick="filter(\''.substr($datas[$i],4,39).'\',\'\')">'.substr($datas[$i],intval($structure['ZC'][$k]['position'])-1+4,intval($structure['ZC'][$k]['length'])).'</td>'."\n";
			}else{
				echo '					<td'.$color.'>'.substr($datas[$i],intval($structure['ZC'][$k]['position'])-1+4,intval($structure['ZC'][$k]['length'])).'</td>'."\n";
			}	
		}
	}	
	echo '				</tr>'."\n";
}
echo '			</tbody>'."\n";
echo '		</table>'."\n";

echo '	</div>'."\n";
?>