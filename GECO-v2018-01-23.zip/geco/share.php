<?php
include 'vars.php';
$root=($root=='') ? '': $root.'/';
if($os_serveur=='unix'){
	header('Content-Type: text/html; charset=utf-8');
}else{	
	header('Content-Type: text/html; charset=ISO-8859-15');
}	

$id=$_COOKIE['id'];

if (!is_dir('share/')){
	mkdir('share/');
}
$upload = 'upload/';
$path=$upload.$id.'/';
if (!is_dir($path)){
	mkdir($path);
}

if(isset($_POST['todo'])){
	switch ($_POST['todo']) {
		case 'share':
			$time=time();
			copy($path.'analyse.txt','share/analyse'.$id.$time.'.txt');
			copy($path.'infos.txt','share/infos'.$id.$time.'.txt');
			if(isset($_POST['comment'])){
				$infos = explode("\n",file_get_contents('share/infos'.$id.$time.'.txt'));
				$fp = fopen ('share/infos'.$id.$time.'.txt', "w+");
				fputs ($fp, "[config]\n");
				fputs ($fp, $_POST['comment']."\n");
				for($i=2;$i<count($infos);$i++){
					fputs ($fp, $infos[$i]."\n");
				}
				fclose ($fp);	
			}
			break;
		case 'delete':
			unlink('share/analyse'.$_POST['filename'].'.txt');
			unlink('share/infos'.$_POST['filename'].'.txt');
			break;
	}
}
$files = scandir('share/',1);
?>
<html>
 <head>
	<title>Comparateur de fichier GEST - Partage / Historique</title>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="publisher" content="MINISTERE DE LA JUSTICE">
	<meta name="author" lang="fr" content="jean-Jacques Dussol">
	<meta name="reply-to" content="jean-jacques.dussol@justice.gouv.fr">
	<link rel="shortcut icon" href="geco.ico" type="image/x-icon">
	<link rel="icon" href="geco.ico" type="image/x-icon">
	<link rel="stylesheet" href="css/geco.css" type="text/css">
    <script type='text/javascript' src="js/jquery.js"></script>
	<script type="text/javascript" src="js/jquery-ui.js"></script>
	<link rel="stylesheet" href="js/jquery-ui.css" type="text/css">
<script type="text/javascript">
	$(document).ready(  
		function(){
			$( "#dialog" ).dialog({
			  width: 500,
			  autoOpen: false,
			  modal: true,
			  buttons: {
				"Oui": function() {
				  efface();
				  },
				"Non": function() {
				  $( this ).dialog( "close");
				}
			  }
			});
		}
	);
	function efface(){
		document.compare.action="share.php";
		document.compare.todo.value='delete';
		document.compare.submit();
	}
	function copy(target){
		eval(target).select();
		if(!document.execCommand("copy")){
			alert('La copie a �chou�e..');
			return;
		}else{
			alert('Le lien a �t� copi� dans le presse papier !');
		}
	}
</script>
 </head>
 <body>
<div class="barre">Comparateur de fichier GEST</div>
<div class="nav">
<ul>
  <li><span onclick="document.location='./'">Accueil</span></li>
  <li><span onclick="document.compare.submit()"> Retour &aacute; la liste</span></li>
</ul>
</div>

 <div class='titre' style="clear:both;margin-top:10px">T&eacute;l&eacute;chargement des fichiers gest</div>
<form method="POST" name="compare" action="compare.php" enctype="multipart/form-data" style="clear:both">
	<input type="hidden" name="todo" value="">
	<input type="hidden" name="filename" value="">
</form>
	<div id="dialog" title="Etes-vous s&ucirc;r de vouloir effacer ce fichier ?">
	</div>	
<form name="filebox">
<?php
date_default_timezone_set('Europe/Paris');
$bgcolor='';
$n=0;
foreach ($files as $key => $value){
	if(strpos($value,'analyse')!==false && strpos($value,$id)==7){
		$infos = explode("\n",file_get_contents('share/infos'.substr($value,7,strpos($value,'.')-7).'.txt'));
		$explain=($infos[4]=='0') ? 'Comparaison de fichier' : 'Analyse fichier seul';
		if($infos[4]=='0'){
			$explain.=($infos[2]=='0') ? ' Correction des �carts' : ' Comparaison exacte';
			$explain.=($infos[3]=='0') ? ' Erreurs seulement' : ' Toutes les lignes';
		}	
		$title=($infos[1]!='') ? '<div class="titre_histo">'.$infos[1].'</div>' : '';
		$lien='compare.php?share='.substr($value,7,strpos($value,'.')-7);
		$body='En cliquant sur ce Lien, vous allez acc�der au fichier de comparaison %0D%0A%0D%0Ahttp://'.$http_host.'/'.$root.$lien.'%0D%0A%0D%0AFichier g�n�r� le '.date ('d m Y H:i:s.', filemtime('share/'.$value));
		$bgcolor=($n==0) ? 'background-color:#eeeeee;border:3px solid #086A87;' : 'border:1px solid #086A87;';
		$n++;
		echo '<div style="clear:both;margin-top:2px;'.$bgcolor.'">';
		echo $title;
		echo '&nbsp;<a href="#" onclick="document.compare.filename.value=\''.substr($value,7,strpos($value,'.')-7).'\';$(\'#dialog\').dialog(\'open\')" title="Effacer le fichier."><img src="images/trash.png" border=0 style="margin-top:6px"></a>'."\n";
		echo '&nbsp;<a href="#" onclick="copy(\'document.filebox.file'.$n.'\')" title="Copier le lien dans le presse-papier."><img src="images/clipboard.png" border=0 style="margin-top:6px"></a>'."\n";
		echo '&nbsp;<a href="#" onclick="document.location=\'mailto:?subject=Fichier de comparaison fichier Gest [Geco]&body='.$body.'\'" title="Envoyer le lien par mail."><img src="images/mail.png" border=0 style="margin-top:6px"></a>'."\n";
		echo '&nbsp;<a href="'.$lien.'">'.substr($value,7,strpos($value,'.')-7).' <i>du '.date ('d m Y H:i:s.', filemtime('share/'.$value)).'</i></a>&nbsp;'.$explain.'<br>'."\n";
		echo '&nbsp;<input name="file'.$n.'" onclick="copy(\'document.filebox.file'.$n.'\')" type="text" style="width:90%;margin-top:5px;margin-bottom:10px;padding:3px;border:1px solid #086A87;color:#086A87;" value="http://'.$http_host.'/'.$root.$lien.'">'."\n";
		echo '</div><br>'."\n";
	}	
	if(strpos($value,'analyse')!==false && floor((time()-filemtime('share/'.$value))/86400)>90){ // si fichier plus de 90 jours --> auto nettoyage
		unlink('share/'.$value);
		unlink('share/'.$value);
	}
}
include 'licence.php';
?>
</form>
</body>
</html>