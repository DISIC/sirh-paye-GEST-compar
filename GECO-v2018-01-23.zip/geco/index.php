<!DOCTYPE html>
<html>
 <head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="publisher" content="MINISTERE DE LA JUSTICE">
	<meta name="author" lang="fr" content="jean-Jacques Dussol">
	<meta name="reply-to" content="jean-jacques.dussol@justice.gouv.fr">
	<link rel="shortcut icon" href="geco.ico" type="image/x-icon">
	<link rel="icon" href="geco.ico" type="image/x-icon">
	<title>Comparateur de fichier GEST - Accueil</title>
    <script type='text/javascript' src="js/jquery.js"></script>
	<script type="text/javascript" src="js/jquery-ui.js"></script>
	<link rel="stylesheet" href="js/jquery-ui.css" type="text/css">
	<script type='text/javascript' src='js/geco.js'></script>    
	<link rel="stylesheet" href="css/geco.css" type="text/css">
    <script>
		$(document).ready(  
			function(){
				$( "#progressbar" ).progressbar({
				  value: false
				});
				$( "#progressbar" ).find( ".ui-progressbar-value" ).css({"background":"#42c0FB"});
				$( "#jauge" ).dialog({
			      closeOnEscape: false,
				  open: function(event, ui) {
					$(".ui-dialog-titlebar-close").hide();
				  },				
				  width: 200,
				  autoOpen: false,
				  modal: true
				});
				if ($('#sn1').width()>=$('#sn2').width()){
					$('#sn2').css("width", $('#sn1').width()+'px')
				}else{
					$('#sn1').css("width", $('#sn2').width()+'px')
				}
			}
		);
	</script>	
 </head>
 <body>
<div class="barre">Comparateur de fichier GEST</div>
<div class="nav">
	<ul>
		<li><span id="m6" onclick="historique()">Historique</span></li>
		<li><a href="config.php"><img src="images/info.png" border=0></a></li>
	</ul>
</div>

<div class='titre' style="clear:both;margin-top:10px;margin-bottom:20px;">T&eacute;l&eacute;chargement des fichiers gest</div>
<form method="POST" action="upload.php" enctype="multipart/form-data" style="clear:both">
<?php
include 'vars.php';
if(isset($_COOKIE['id'])){
	if(strlen($_COOKIE['id'])!=32){
		$id=$_COOKIE['id'];
	}else{
		$id=uniqid();
		setcookie('id',$id, time() + (10*365*24*3600));
	}
}else{
	$id=uniqid();
	setcookie('id',$id, time() + (10*365*24*3600));
}
$upload = 'upload/';

$path=$upload.$id.'/';

date_default_timezone_set('Europe/Paris');
echo '<div style="float:left">Fichier gest&nbsp;</div><div style="float:left;background-color:#dddddd" id="sn1">&nbsp;<b>'.$SI['S1'].'</b>&nbsp;</div>';
if (file_exists($path.'gest1.txt')) {
    echo '<div style="float:left;width:250px;margin-left:5px"> du ' . date ('d m Y H:i:s.', filemtime($path.'gest1.txt')).'</div>';
}else{
    echo '<div style="float:left;width:250px;margin-left:5px"> Aucun fichier charg&eacute;</div>';
}
?>
    <div style="float:left;"><input type="file" name="fichier" onChange="this.form.submit()" style="cursor:pointer;color:white"></div>
	<input type="hidden" name="fic" value="1">
</form>
<form method="POST" action="upload.php" enctype="multipart/form-data" style="clear:both">
<?php
date_default_timezone_set('Europe/Paris');
echo '<div style="float:left">Fichier gest&nbsp;</div><div style="float:left;background-color:#dddddd" id="sn2">&nbsp;<b>'.$SI['S2'].'</b>&nbsp;</div>';
if (file_exists($path.'gest2.txt')) {
    echo '<div style="float:left;width:250px;margin-left:5px"> du ' . date ('d m Y H:i:s.', filemtime($path.'gest2.txt')).'</div>';
}else{
    echo '<div style="float:left;width:250px;margin-left:5px"> Aucun fichier charg&eacute;</div>';
}
?>
    <div style="float:left;"><input type="file" name="fichier" onChange="this.form.submit()" style="cursor:pointer;color:white"></div>
	<input type="hidden" name="fic" value="2">
</form>

<form name="compare" id="compare" action="analyse.php" method="POST" style="clear:both">
<input type="hidden" name="todo" value="">
<?php
if (file_exists($path.'gest1.txt') && file_exists($path.'gest2.txt')) {
?>
<div class='titre' style="margin-top:50px;margin-bottom:20px;">Lancement de la comparaison des fichiers gest</div>
	Afficher toute les lignes&nbsp;<INPUT type= "radio" name="all" value="1">
	Afficher les erreurs seulement&nbsp;<INPUT type= "radio" name="all" value="0" checked><br>
	&nbsp;<br>
	Comparaison exacte <input type="checkbox" name="cb_exact" onClick="this.form.exact.value=this.checked ? 1 : 0;"><br>
	&nbsp;<br>
	<input type="hidden" name="exact" value="0">
    <img src="images/compare.png" style="margin-right:40px"><a href="#" onclick="document.compare.alone.value=0;analyse()" class="btn">Comparer les fichiers</a>
<?php
}
if (file_exists($path.'gest1.txt')){
?>
<div class='titre' style="margin-top:100px;margin-bottom:20px;">Lancement de l'analyse du premier fichier gest</div>
	<img src="images/analyse.png" width=50 style="margin-right:50px"><a href="#" class="btn" onClick="document.compare.alone.value=1;analyse()">&nbsp;&nbsp;&nbsp;Analyser le fichier&nbsp;&nbsp;</a>
	<input type="hidden" name="alone" value="">
<?php
}
	
include 'licence.php';
?>
</form>
<div id="jauge" title="Analyse en cours">
	&nbsp;<br>
	<div id="progressbar"></div>
</div>	
</body>
</html>