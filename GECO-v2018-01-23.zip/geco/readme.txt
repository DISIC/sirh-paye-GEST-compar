Les valeurs de paramétrage des mouvements peuvent être modifiées par l'administrateur du système dans le fichier VARS.PHP
Dans ce même fichier, peuvent être paramétrés :
♦ les noms des 2 SI sources ($SI1, $SI2)
♦ l'OS du serveur ($os_serveur windows ou unix)
♦ l'adresse de l'hôte par defaut $http_host
Pour fonctionner correctement, l'administrateur du système doit donner aux sous-répertoire upload et share de l'application des droits en création de répertoire et lecture-écriture de fichiers.
Par défaut, la taille maximale d'upload des fichiers est définie à 2Mo.
Pour des fichiers de taille supérieure, il faut modifier le fichier php.ini et définir la valeur upload_max_filesize à 100 Mo et le paramètre post_max_size à 100 Mo par exemple.
!Attention le serveur web lui-même (IIS / Apache) peut avoir des paramètres limitant la taille maximale des fichiers uploadés.
Pour éviter l'affichage de message d'avertissement, modifier le paramètre de rapport d'erreur comme suit : error_reporting = E_ALL & ~E_NOTICE  
