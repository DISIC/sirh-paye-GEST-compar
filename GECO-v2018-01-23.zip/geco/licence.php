<div id="copyright">
	<a rel="license" href="http://creativecommons.org/licenses/by-nc/4.0/deed.fr"><img src="images/creative-commons.png" width=75 border=0 align="absmiddle"></a>
	D&eacute;veloppement <span style="color:#8cc608;font-size:16px">&bull;</span> Jean-Jacques Dussol Minist&egrave;re de la Justice Secr&eacute;tariat g&eacute;n&eacute;ral / SSIC / SDIDE / DED / P&ocirc;le SIRH <span style="color:#00529c;font-size:16px">&bull;</span><span style="color:#f7751a;font-size:16px">&bull;</span> Harmonie 
</div>
