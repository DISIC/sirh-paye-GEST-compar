<!DOCTYPE html>
<html lang="fr">
<head>
	<title>Un erreur est survenue !</title>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="publisher" content="MINISTERE DE LA JUSTICE">
	<meta name="author" lang="fr" content="jean-Jacques Dussol">
	<meta name="reply-to" content="jean-jacques.dussol@justice.gouv.fr">
	<link rel="shortcut icon" href="geco.ico" type="image/x-icon">
	<link rel="icon" href="geco.ico" type="image/x-icon">
	<link rel="stylesheet" href="css/geco.css" type="text/css">
    <script type='text/javascript' src="js/jquery.js"></script>
</head>
<body>
<?php
flush();
?>
<div class="barre">Comparateur de fichier GEST <br>&nbsp;<br><span style="color:red">Le fichier n'existe pas ou a &eacute;t&eacute; supprim&eacute;</span></div>
</body>
</html>





