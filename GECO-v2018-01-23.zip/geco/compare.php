<?php
include 'vars.php'; // r�cup�re les variables
if($os_serveur=='unix'){
	header('Content-Type: text/html; charset=utf-8');
}else{	
	header('Content-Type: text/html; charset=ISO-8859-15');
}	
ini_set('output_buffering','1');

$id=$_COOKIE['id'];

$share='';
if(isset($_GET['share'])){
	$share=$_GET['share'];
}

if($share==''){
	$path='upload/'.$id.'/';
	$GET='';
}else{
	$path='share/';
	$GET='?share='.$share;
	if (! file_exists($path.'infos'.$share.'.txt')) {
		header('Location: ./error.php');
	}	
}

$datas = explode("\n",file_get_contents($path.'infos'.$share.'.txt'));
$comment=$datas[1];
$exact=$datas[2];
$all=$datas[3];;
$alone=$datas[4];
$gest1=$datas[6];
$gest2=$datas[7];
$mouvements1=$datas[8];
$mouvements2=$datas[9];
$mvt_manquants1=$datas[10];
$mvt_manquants2=$datas[11];
$dossiers_manquants1=explode(';',$datas[12]);
$dossiers_manquants2=explode(';',$datas[13]);

//echo 'XX/'.$exact."/".$all."/".$alone.'/'.$share;

$nb1=explode(';',$datas[14]);
$nb2=explode(';',$datas[15]);
$erreurs=explode(';',$datas[16]);	
?>
<!DOCTYPE html>
<html lang="fr">
<head>
	<title>Comparateur de fichier Gest - R�sultat de l'analyse</title>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="publisher" content="MINISTERE DE LA JUSTICE">
	<meta name="author" lang="fr" content="jean-Jacques Dussol">
	<meta name="reply-to" content="jean-jacques.dussol@justice.gouv.fr">
	<link rel="shortcut icon" href="geco.ico" type="image/x-icon">
	<link rel="icon" href="geco.ico" type="image/x-icon">
	<link rel="stylesheet" href="css/geco.css" type="text/css">
    <script type='text/javascript' src="js/jquery.js"></script>
	<script type='text/javascript' src='js/geco.js'></script>    
	<script type="text/javascript" src="js/jquery-ui.js"></script>
	<script type='text/javascript' src='js/picnet.table.filter.min.js'></script>    
	<link rel="stylesheet" href="js/jquery-ui.css" type="text/css">
<script>
	tabfilter=<?php echo $TabFilter?>;
	$(document).ready(  
		function(){
			if ($('#sn1').width()>=$('#sn2').width()){
				$('#sn2').css("width", $('#sn1').width()+'px')
			}else{
				$('#sn1').css("width", $('#sn2').width()+'px')
			}
			$( "#progressbar" ).progressbar({
			  value: false
			});
			$( "#progressbar" ).find( ".ui-progressbar-value" ).css({"background":"#42c0FB"});
			$( "#jauge" ).dialog({
			  closeOnEscape: false,
			  open: function(event, ui) {
				$(".ui-dialog-titlebar-close").hide();
			  },				
			  width: 250,
			  autoOpen: false,
			  modal: true
			});
			$( "#dialog" ).dialog({
			  width: 500,
			  autoOpen: false,
			  modal: true,
			  buttons: {
				"Partager": function() {
					document.compare.action='share.php';
					document.compare.todo.value='share';
					document.compare.submit();
				  },
				"Annuler": function() {
				  $( this ).dialog( "close");
				}
			  }
			});
		}
	);
</script>	
</head>
<body>
<?php
flush();

$mouvement=array_keys($mouvements_libelle);
unset($mouvement[count($mouvement)-1]);

// Chargement des structure
$structure = json_decode($mouvements_structure,true);

?>
<form name="compare" method="POST" action="compare.php<?php echo $GET?>" style="clear:both">
	<input type="hidden" name="all" id="all" value="<?php echo $all?>">
	<input type="hidden" name="exact" id="exact" value="<?php echo $exact?>">
	<input type="hidden" name="alone" id="alone" value="<?php echo $alone?>">
	<input type='hidden' name="share" id="share" value="<?php echo $share?>">
	<input type="hidden" name="dossier" value="">
	<input type="hidden" name="todo" value="">
	<input type="hidden" name="comment" value="">
	<div id="dialog" style="display:none" title="Etes-vous s&ucirc;r de vouloir partager cette analyse ?">
		<label for "commentaire">Commentaire sur l'analyse</label><br>
		<input type="text" name="commentaire" style="width:100%" onChange="document.compare.comment.value=this.value">
	</div>	
</form>
<div class="barre" id="isTop">Comparateur de fichier GEST</div>
<div class="nav">
	<ul>
<?php
if(!isset($_GET['share'])){
?>
		<li><span id="m1" onclick="document.location='./'">Accueil</span></li>
<?php
} 
?>
		<li><span id="m2" class="active" onclick="volumetrie('')">Volum&eacute;trie</span></li>
		<li><span id="m3" onclick="comparer()">Analyse</span></li>
		<li><span id="m7" onclick="document.location='export.php'"><img src="images/excel.png" align="absmiddle">Export</span></li>
<?php
	 if(!isset($_GET['share'])){
	?>  
		<li><span id="m5" onclick="$('#dialog').dialog('open')">Partager</span></li>
		<li><span id="m6" onclick="historique()">Historique</span></li>
		<li><a href="config.php"><img src="images/info.png" border=0></a></li>
	<?php
	}

?>  
	</ul>
</div>
&nbsp;<br>
<?php

//Affichage volum�tries
?>
<div id="totaux">
	<table style="font-size:16px;width:100%;margin-top:50px;margin-top:10px">
<?php
if($alone!='1'){
	$complement=""
?>
		<tr>
			<th>Nombre total d'enregistrements dans le fichier GEST <?php echo $SI['S1']?></th>
			<th>Nombre total d'enregistrements dans le fichier GEST <?php echo $SI['S2']?></th>
		</tr>
		<tr>
			<td style="text-align:center;font-weight:bold"><?php echo $gest1?></td>
			<td style="text-align:center;font-weight:bold"><?php echo $gest2?></td>
		</tr>
		<tr>
			<th>Nombre d'agents dans le fichier GEST <?php echo $SI['S1']?></th>
			<th>Nombre d'agents dans le fichier GEST <?php echo $SI['S2']?></th>
		</tr>
		<tr>
			<td style="text-align:center;font-weight:bold"><?php echo $mouvements1?></td>
			<td style="text-align:center;font-weight:bold"><?php echo $mouvements2?></td>
		</tr>
		<tr>
			<th>Nombre de mouvements manquants dans le fichier GEST <?php echo $SI['S1']?></th>
			<th>Nombre de mouvements manquants dans le fichier GEST <?php echo $SI['S2']?></th>
		</tr>
		<tr>
			<td style="text-align:center;font-weight:bold"><?php echo $mvt_manquants1?></td>
			<td style="text-align:center;font-weight:bold"><?php echo $mvt_manquants2?></td>
		</tr>
		<tr>
		<th>Dossiers pr&eacute;sents dans <?php echo $SI['S1']?> et absents de <?php echo $SI['S2']?></th>
		<th>Dossiers pr&eacute;sents dans <?php echo $SI['S2']?> et absents de <?php echo $SI['S1']?></th>
		</tr>
		<tr>
			<td style="text-align:center;font-weight:bold" valign="top"><?php echo count($dossiers_manquants2)?></td>
			<td style="text-align:center;font-weight:bold" valign="top"><?php echo count($dossiers_manquants1)?></td>
		</tr>
		<tr>
			<td style="font-weight:bold" valign="top">
			<?php
			for($i=0;$i<count($dossiers_manquants2);$i++){
				echo $dossiers_manquants2[$i].'<br>'."\n";
			}
			?>
			</td>
			<td style="font-weight:bold" valign="top">
			<?php
			for($i=0;$i<count($dossiers_manquants1);$i++){
				echo $dossiers_manquants1[$i].'<br>'."\n";
			}
			?>
			</td>
		</tr>
<?php
} else {
	$complement=' ('.$gest1.' enregistrements pour '.$mouvements1.' dossiers)';
}
?>
	</table>
	<table style="font-size:14px;width:100%;margin-top:50px;margin-top:10px">
		<tr>
			<th colspan=<?php echo count($mouvement)?>>DENOMBREMENT DES MOUVEMENTS DANS LE FICHIER GEST <?php echo $SI['S1'].$complement?></th>
		</tr>
		<tr>
<?php
			for($i=0;$i<count($nb1);$i++){
				$style=($nb1[$i]!=$nb2[$i]) ? ' style="background-color:#F6CECE;font-weight:bold"' : ' style="font-weight:bold"';
				echo '			<td'.$style.' title="'.$mouvements_libelle[$mouvement[$i]].'">'.$mouvement[$i].'</td>'."\n";
			}
?>
		</tr>
		<tr>
<?php		
			for($i=0;$i<count($nb1);$i++){
				$style=($nb1[$i]!=$nb2[$i]) ? ' style="background-color:#F6CECE"' : '';
				echo '			<td'.$style.' title="'.$mouvements_libelle[$mouvement[$i]].'">'.$nb1[$i].'</td>'."\n";
			}
?>
		</tr>
	</table>
<?php
if($alone!='1'){
?>
	<table style="font-size:14px;width:100%;margin-top:50px;margin-top:10px">
		<tr>
			<th colspan=<?php echo count($mouvement)?>>DENOMBREMENT DES MOUVEMENTS DANS LE FICHIER GEST <?php echo $SI['S2']?></th>
		</tr>
		<tr>
<?php
			for($i=0;$i<count($mouvement);$i++){
				$style=($nb1[$i]!=$nb2[$i]) ? ' style="background-color:#F6CECE;font-weight:bold"' : ' style="font-weight:bold"';
				echo '			<td'.$style.' title="'.$mouvements_libelle[$mouvement[$i]].'">'.$mouvement[$i].'</td>'."\n";
			}
?>
		</tr>
		<tr>
<?php		
			for($i=0;$i<count($nb2);$i++){
				$style=($nb1[$i]!=$nb2[$i]) ? ' style="background-color:#F6CECE"' : '';
				echo '			<td'.$style.' title="'.$mouvements_libelle[$mouvement[$i]].'">'.$nb2[$i].'</td>'."\n";
			}
?>
		</tr>
	</table>
	<table style="font-size:14px;width:100%;margin-top:50px;margin-top:10px">
		<tr>
			<th colspan=<?php echo count($mouvement)?>>DENOMBREMENT DES ERREURS</th>
		</tr>
		<tr>
<?php
			for($i=0;$i<count($erreurs);$i++){
				$style=($erreurs[$i]!=0) ? ' style="font-weight:bold;background-color:#ff5050"' : '';
				echo '			<td'.$style.' title="'.$mouvements_libelle[$mouvement[$i]].'">'.$mouvement[$i].'</td>'."\n";
			}
?>
		</tr>
		<tr>
<?php
			for($i=0;$i<count($erreurs);$i++){
				$style=($erreurs[$i]!=0) ? ' style="background-color:#ff5050"' : '';
				echo '			<td'.$style.' title="'.$mouvements_libelle[$mouvement[$i]].'">'.$erreurs[$i].'</td>'."\n";
			}
?>
		</tr>
	</table>
<?php
}
?>
	&nbsp;<br>
	&nbsp;<br>
</div>
<?php
//Fin affichage volum�tries

//Affichage acc�s rapide
echo '<div id="quickaccess" style="display:none">'."\n";
echo '	<div style="width:30%;float:left;font-weight:bold">Acc�s rapide aux mouvements... </div><div style="width:70%;float:left;text-align:right"><img src="images/magnify.png" align="absmiddle" style="margin-right:5px"><input type="text" name="recherche" id="recherche" style="width:250px;border : 1px solid #086A87" onKeyPress="if (event.keyCode == 13){filter(this.value,\'\');this.value=\'\'}" placeholder="Recherche par nom ou NIR"></div>'."\n";
echo '&nbsp;<br>';
echo '	<div style="clear:both;" class="barre_bouton">'."\n";
for($i=0;$i<count($mouvement);$i++){
	$compare=($alone=='1' || $all=='1') ? $nb1[$i] : $erreurs[$i];
	if($compare!=0){
		echo '		<span class="bouton" onclick="filter(\''.$mouvement[$i].'\',\'mvt\')">'.$mouvement[$i].'</span>'."\n";
	}
}
echo '	</div>'."\n";
echo '	<div style="margin-bottom:25px;width:25%;float:left;background-color:#BED6E1;">Ligne valide</div><div style="margin-bottom:25px;width:25%;float:left;background-color:#F5BCA9">Ligne &agrave; v&eacute;rifier</div><div style="margin-bottom:25px;width:25%;float:left;background-color:#BBBBBB;">Ligne non trouv&eacute;e</div><div style="margin-bottom:25px;width:25%;float:left;background-color:#F5DA81;">Ligne en doublon</div>'."\n";
echo '</div>'."\n";
//Affichage acc�s rapide

// Affichage du r�sultat
echo '<div id="resultats" style="display:none">';
include 'filter.php';
echo '</div>';
// Fin affichage des r�sultats

?>
&nbsp;<br>
&nbsp;<br>
&nbsp;<br>
<?php
include 'licence.php';
?>
<div id="jauge" title="Chargement en cours">
	&nbsp;<br>
	<div id="progressbar"></div>
</div>	
<script type="text/javascript">
	$(document).ready(function(){
		if(tabfilter==1){
			var filter_options={
				additionalFilterTriggers: [$('#quickfind')]
			}	
			$("#quicksearch").tableFilter(filter_options);
		}	
	});
</script>
</body>
</html>





