<?php
$fic=$_POST['fic'];


if(!isset($erreur)){

	//Les fichiers sont stock�s dans un r�pertoire perso en focntion de l'adresse IP
	$id=$_COOKIE['id'];
	$upload = 'upload/';
	if (!is_dir($upload)){
		mkdir($upload);
	}
	$path=$upload.$id.'/';
	if (!is_dir($path)){
		mkdir($path);
	}

	$fichier = 'gest'.$fic.'.txt';
	if (file_exists($path.'analyse.txt')){
		unlink($path.'analyse.txt');
		unlink($path.'infos.txt');
	}	

	if(!move_uploaded_file($_FILES['fichier']['tmp_name'], $path. $fichier)){ //Si la fonction renvoie TRUE, c'est que �a a fonctionn�...
		  $erreur='Echec de l\'upload !';
	 } else{
		if($fic=='1'){
			file_put_contents($path.$id.'.log', 'chargement de fichier le : '.date("d-m-Y H:i:s")."\r\n", FILE_APPEND);
		}	
		header('Location: ./');
	 }
}
?>
<div style="color:red;font-family:Arial;font-size:16px;margin-top:150px;text-align:center;width:100%">
<?php
echo $erreur. '<br><a href="./">Retour &agrave; la page d\'accueil</a>'
?>
</div>