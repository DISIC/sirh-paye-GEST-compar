function volumetrie(){
	if($('#m2').attr("class")=="active"){
		return;
	}			
	$('#m2').attr("class","active"); 
	$('#m3').attr("class",""); 
	$('#totaux').show();
	$('#resultats').hide();
	$('#quickaccess').hide();
}
function comparer(){
	if($('#m3').attr("class")=="active"){
		return;
	}
	$('#m3').attr("class","active");
	$('#m2').attr("class",""); 
	$('#totaux').hide();
	$('#resultats').show();
	$('#quickaccess').show();
	$('.mouvements').show();
}

function historique(){
	document.compare.action='share.php';
	document.compare.todo.value='histo';
	document.compare.submit();
}


 function filter(value,mvt){
	$('.filter').each(function(i, obj) {
		$('#quicksearch_filter_'+i).val(''); // Effacement des champs de recherche rapide
	});
	$.ajax( {
			beforeSend: function() {
  			 $('#jauge').dialog('open');
			},
			type: "GET",
			cache:false, // Compatibilité IE
			url: "filter.php",
			data: 'value='+value+'&exact='+$('#exact').val()+'&all='+$('#all').val()+'&alone='+$('#alone').val()+'&share='+$('#share').val(),
			dataType: "text",
			contentType: "text/plain; charset=ISO-8859-1",
			success: function(datas) 
					 {	
						$("#resultats").html(datas);
						$('#jauge').dialog('close');
						// Si affichage par mouvements et filtre activé alors ajout filtre
						if(mvt!='' && tabfilter==1){
							var filter_options={
								additionalFilterTriggers: [$('#quickfind')]
							}	
							$("#quicksearch").tableFilter(filter_options);
						}	
					 }
	});
 }

function analyse(){
	$.ajax( {
			beforeSend: function() {
  			 $('#jauge').dialog('open');
			},
			type: $("#compare").attr('method'),
			cache:false, // Compatibilité IE
			url:  $("#compare").attr('action'),
			data: $("#compare").serialize(),
			success: function(datas) 
					 {	
						document.location="compare.php";
					 }
	});
 }
