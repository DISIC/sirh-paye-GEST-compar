<?php
include 'vars.php'; // r�cup�re les variables
if($os_serveur=='unix'){
	header('Content-Type: text/html; charset=utf-8');
}else{	
	header('Content-Type: text/html; charset=ISO-8859-15');
}	
?>
<!DOCTYPE html>
<html lang="fr">
<head>
	<title>Comparateur de fichier Gest - Concept et configuration</title>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="publisher" content="MINISTERE DE LA JUSTICE">
	<meta name="author" lang="fr" content="jean-Jacques Dussol">
	<meta name="reply-to" content="jean-jacques.dussol@justice.gouv.fr">
	<link rel="shortcut icon" href="geco.ico" type="image/x-icon">
	<link rel="icon" href="geco.ico" type="image/x-icon">
	<link rel="stylesheet" href="css/geco.css" type="text/css">
    <script type='text/javascript' src="js/jquery.js"></script>
</head>
<body>
<?php
flush();

// Chargement des structure
$structure = json_decode($mouvements_structure,true);

$mouvement=array_keys($mouvements_libelle);
unset($mouvement[count($mouvement)-1]);

?>
<div class="barre">Comparateur de fichier GEST</div>
<div class="nav">
<ul>
  <li onclick="parent.history.back();"><span>Retour</span></li>
</ul>
</div>
&nbsp;<br>
<?php

echo '&nbsp;<br>'."\n";
?>
<img src="images/info.png" valign=left style="border:1px solid #086A87;padding:2px"><br>En mode comparaison exacte, le comparateur de fichier Gest compare les deux fichiers ligne &agrave; ligne.<br>
Pour &eacute;viter certains &eacute;cart de gestion, le mode exact peut &ecirc;tre d&eacute;sactiv&eacute;.<br>
Dans ce cas : la comparaison ne se fait pas sur une ligne compl&egrave;te mais sur la concat&eacute;nation
de <b>zone communes (ZC)</b> pour lesquels la valeur compare est &eacute;gale &agrave; 1 (vrai) aux champs sp&eacute;cifiques du <b>mouvement</b> pour lesquels la valeur compare est &eacute;gale &agrave; 1 (vrai).<br />
Par exemple, sur un <b>mouvement 04</b>, le libell&eacute; de la banque peut &ecirc;tre diff&eacute;rent entre les deux SI (<i>St&eacute; g&eacute;n&eacute;rale</i> <b>vs</b> <i>SOCIETE GENERALE</i>) mais correspondent &agrave; la m&ecirc;me banque.<br>
En mettant la valeur compare du champs <b>LIB_BAN</b> &agrave; 0 (faux), le nom de la banque ne sera pas pris en compte et l'&eacute;cart ne sera pas affich&eacute;.<br>
&nbsp;<br>
<img src="images/settings.png" valign=left style="border:1px solid #086A87;padding:2px"><br>Les tableaux ci-dessous donne le param&eacute;trage par d&eacute;faut pour tous les mouvements. Les valeurs peuvent &ecirc;tre modifi&eacute;es par l'administrateur du syst&egrave;me dans le fichier <i>VARS.PHP</i><br>
&nbsp;<br>
Dans ce m&ecirc;me fichier, peuvent &ecirc;tre param&eacute;tr&eacute;s :<br>
&diams;&nbsp;les noms des 2 SI sources (<i>$SI1, $SI2</i>)<br>
&diams;&nbsp;l'OS du serveur (<i>$os_serveur</i> windows ou unix)<br>
&diams;&nbsp;l'adresse de l'h&ocirc;te <i>$http_host</i><br>
Pour fonctionner correctement, l'administrateur du syst&egrave;me doit donner aux sous-r&eacute;pertoire <i><b>upload</b></i> et <i><b>share</b></i> de l'application des droits en cr&eacute;ation de r&eacute;pertoire et lecture-&eacute;criture de fichiers.<br>
Par d&eacute;faut, la <b>taille maximale d'upload des fichiers</b> est d&eacute;finie &agrave; 2Mo. Pour des fichiers de taille sup&eacute;rieure, il faut modifier le fichier php.ini et d&eacute;finir la valeur <i>upload_max_filesize</i> &agrave; 100 Mo ou plus ainsi que la valeur <i>post_max_size</i> � 100 Mo ou plus. Pour �viter l'affichage de messages d'avertissement, modifier le param&egrave;tre de rapport d'erreur comme suit : <i>error_reporting = E_ALL & ~E_NOTICE</i>
&nbsp;<br>
<?php
echo '&nbsp;<br>'."\n";

affiche('ZC');
for($i=0;$i<count($mouvement);$i++){
	affiche($mouvement[$i]);
}

function affiche($mvt){
	global $structure,$mouvements_libelle;
		echo ($mvt=='ZC') ? '<span class="titre">'.$mvt.'</span>&nbsp;<span style="font-weight:bold"><span class="libelle">'.$mouvements_libelle['ZC'].'</span>'."<br>\n" : '<span class="titre">MVT '.$mvt.'</span><span class="libelle">'.$mouvements_libelle[$mvt]."<br>\n";
		echo '<table style="border-collapse:separate">'."\n";
		echo '<thead >'."\n";
		if($mvt=='ZC'){
			echo '<tr><th style="background-color:#ffffff;color:#000000"></th><th style="background-color:#ffffff;color:#000000" colspan=10>Debut de la ligne</th><th style="background-color:#ffffff;color:#000000" colspan=4>Fin de la ligne</th></tr>';
		}
		echo '<tr ><th style="background-color:#ffffff;color:#000000">CHAMP</th>'."\n";
		for($k=0;$k<count($structure[$mvt]);$k++)
		{
			echo '<th title="'.$structure[$mvt][$k]['comment'].'">'.$structure[$mvt][$k]['field'].'</th>'."\n";
		}	
		echo '</tr>'."\n";
		echo '<tr><th style="background-color:#ffffff;color:#000000">CLEF</th>'."\n";
		for($k=0;$k<count($structure[$mvt]);$k++)
		{
			$color=($structure[$mvt][$k]['key']=='0') ? '#aaaaaa' : '#B43104';
			echo '<th style="background-color:'.$color.'" title="'.$structure[$mvt][$k]['comment'].'">'.$structure[$mvt][$k]['key'].'</th>'."\n";
		}	
		echo '</tr>'."\n";
		echo '<tr><th style="background-color:#ffffff;color:#000000">COMPARAISON</th>'."\n";
		for($k=0;$k<count($structure[$mvt]);$k++)
		{
			$color=($structure[$mvt][$k]['compare']=='0') ? '#aaaaaa' : '#B43104';
			echo '<th style="background-color:'.$color.'" title="'.$structure[$mvt][$k]['comment'].'">'.$structure[$mvt][$k]['compare'].'</th>'."\n";
		}	
		echo '</tr>'."\n";
		echo '</thead >'."\n";

		echo '<tbody>'."\n";
		echo '</tbody>'."\n";
		echo '</table>'."\n";
		echo '&nbsp;<br>'."\n";
}
include 'licence.php';
?>
</body>
</html>





