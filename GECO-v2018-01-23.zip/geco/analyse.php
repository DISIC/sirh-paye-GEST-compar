<?php
include 'vars.php'; // r�cup�re les variables
$id=$_COOKIE['id'];
$path='upload/'.$id.'/';

if(isset($_POST['exact'])){
	//Param�tre comparaison exacte
	$exact=$_POST['exact'];
}else{
	$exact='0';
}

if(isset($_POST['all'])){
	//Param�tre afficher tous les mouvements ou seulement les anos
	$all=$_POST['all'];
}else{
	$all='0';
}
if(isset($_POST['alone'])){
	//Param�tre fichier seul
	$alone=$_POST['alone'];
}else{
	$alone='0';
}
if($alone=='1'){
	$all='1';
}

file_put_contents($path.$id.'.log', 'Analyse : '.date("d-m-Y H:i:s")."\r\n", FILE_APPEND);
	
if(file_exists($path.'analyse.txt')){
	$infos = explode("\n",file_get_contents($path.'infos.txt'));
	if($exact==$infos[2] && $all==$infos[3] && $alone==$infos[4]){
		exit();
	}	
}


$mouvement=array_keys($mouvements_libelle);
unset($mouvement[count($mouvement)-1]);

// Initialisation de variables pour chaque mouvement
for($i=0;$i<count($mouvement);$i++){
	//D�compte des mouvements par fichier Gest
	$nb[1][$mouvement[$i]]=0;
	$nb[2][$mouvement[$i]]=0;
	$nb_erreurs[$mouvement[$i]]=0;
	//Bloc de m�mo des lignes par mouvement
	$bloc[$mouvement[$i]]=null;

}
//Memo des mouvements
$mouvements[1]=array();
$mouvements[2]=array();

//Decompte mouvements manquants
$mvt_manquants[1]=0;
$mvt_manquants[2]=0;

//memo des dossiers (40 premier caract�res de la ligne)
$dossiers[1]=array();
$dossiers[2]=array();

//memo des dossiers manquants
$dossiers_manquants[1]=array();
$dossiers_manquants[2]=array();

// Chargement des structure
$structure = json_decode($mouvements_structure,true);

// On charge le premier fichier
$gest1 = file($path.'gest1.txt',FILE_SKIP_EMPTY_LINES);
//Appel de la fonction charge_bande_gest pour remplir le tableau des clefs associ�es � chaque mouvement
$key1=array();
$key1=charge_key_gest($gest1,1);
if($exact=='1'){
	$base1=$gest1;
}else{
	$base1=charge_bande_gest($gest1,2);
}


// On charge le deuxi�me fichier
if ($alone!='1'){
	$gest2 = file($path.'gest2.txt',FILE_SKIP_EMPTY_LINES);
}else{
	$gest2 = file($path.'gest1.txt',FILE_SKIP_EMPTY_LINES);
}	
//Appel de la fonction charge_bande_gest pour remplir le tableau des clefs associ�es � chaque mouvement
$key2=array();
$key2=charge_key_gest($gest2,2);
if($exact=='1'){
	$base2=$gest2;
}else{
	$base2=charge_bande_gest($gest2,2);
}	

// On effectue l'analyse comparative r�sultat 0 ligne trouv�e 1 ligne diff�rente 2 ligne non trouv�e
$progress=0;
for($i=0;$i<count($base1);$i++){
	if($base1[$i]!=''){
		// on r�cup�re le code du mouvement (en PHP le premier caract�re est le 0)
		if(substr($base1[$i],40-1,1)=="4"){ // Si commence par 4 alors le code est sur 2 caract�re + 1 caract�re code suppl�mentaire
			$mvt=substr($base1[$i],40-1,3);
		}else{
			$mvt=substr($base1[$i],40-1,2); // sinon code sur deux caract�re
		}
		$doublon=false;
		if($i<count($base1)-1){
			if($base1[$i]===$base1[$i+1]){
				$bloc[$mvt][]='3S1 '.$gest1[$i];
				$bloc[$mvt][]='3S1 '.$gest1[$i+1];
				$i++;
				$doublon=true;
				$nb_erreurs[$mvt]++;
			}
		}
		if(!$doublon){
			// recherche d'une correspondance exacte de la ligne de base1 dans base2
			$indx=array_search($base1[$i],$base2,false);
			// si pas trouv� alors on cherche par les tableau des clefs key1 dans key2
			if($indx===false){
				$indx=array_search($key1[$i],$key2,false);
				// Si pas trouv� alors c'est que la ligne n'existe pas
				if($indx===false){
					$bloc[$mvt][]='2S1 '.$gest1[$i];
					$mvt_manquants[2]++;
					$nb_erreurs[$mvt]++;
					$progress++;
					// Sinon c'est que la ligne est diff�rente
				}else{
					$bloc[$mvt][]='1S1 '.$gest1[$i];
					$bloc[$mvt][]='1S2 '.$gest2[$indx];
					$progress+=2;
					$nb_erreurs[$mvt]++;
				}
			// La ligne a �t� trouv�e
			} else {
					if($all=='1' || $alone=='1'){
						$bloc[$mvt][]='0S1 '.$gest1[$i];
						if($alone!='1'){
							$bloc[$mvt][]='0S2 '.$gest2[$indx];
						}	
						$progress+=2;
					}
			}
		}
		// Chaine qui sera stock�e dans $dossiers_manquants
		$identite=substr($gest1[$i],22,13).' ('.trim(substr($gest1[$i],160,20)).' '.trim(substr($gest1[$i],180,13)).') - '.trim(substr($gest1[$i],193,9));
		//On v�rifie si le dossier est manquant et si il n'a pas d�j� �t� m�moris�
		if(array_search(substr($base1[$i],0,37),$dossiers[2])===false && array_search($identite,$dossiers_manquants[2])===false){
			$dossiers_manquants[2][]=$identite;
		}
	}
}
// Pour terminer : recherche des lignes de gest2 absentes de gest1
for($i=0;$i<count($base2);$i++){
	if(substr($base2[$i],40-1,1)=="4"){
		$mvt=substr($base2[$i],40-1,3);
	}else{
		$mvt=substr($base2[$i],40-1,2);
	}
	if(array_search($key2[$i],$key1,false)===false){
		if(array_search($key2[$i],$key1,false)===false){
			$bloc[$mvt][]='2S2 '.$gest2[$i];
			$mvt_manquants[1]++;
			$progress++;
			$nb_erreurs[$mvt]++;
		}	
	}
	// Chaine qui sera stock�e dans $dossiers_manquants
	$identite=substr($gest2[$i],22,13).' ('.trim(substr($gest2[$i],160,20)).' '.trim(substr($gest2[$i],180,13)).')';
	//On v�rifie si le dossier est manquant et si il n'a pas d�j� �t� m�moris�
	if(array_search(substr($base2[$i],0,37),$dossiers[1])===false && array_search($identite,$dossiers_manquants[1])===false){
		$dossiers_manquants[1][]=$identite;
	}
}
$fp = fopen ($path.'infos.txt', "w+");
fputs ($fp, "[config]\n");
fputs ($fp, "\n");
fputs ($fp, $exact."\n");
fputs ($fp, $all."\n");
fputs ($fp, $alone."\n");
fputs ($fp, "[volumetrie]\n");
fputs ($fp, count($gest1)."\n");
fputs ($fp, count($gest2)."\n");
fputs ($fp, count($mouvements[1])."\n");
fputs ($fp, count($mouvements[2])."\n");
fputs ($fp, $mvt_manquants[1]."\n");
fputs ($fp, $mvt_manquants[2]."\n");
fputs ($fp, implode(';',$dossiers_manquants[1])."\n");
fputs ($fp, implode(';',$dossiers_manquants[2])."\n");
$sep='';
for($i=0;$i<count($mouvement);$i++){
	fputs ($fp, $sep.$nb[1][$mouvement[$i]]);
	$sep=';';
}
fputs ($fp, "\n");
$sep='';
for($i=0;$i<count($mouvement);$i++){
	fputs ($fp, $sep.$nb[2][$mouvement[$i]]);
	$sep=';';
}
fputs ($fp, "\n");
$sep='';
for($i=0;$i<count($mouvement);$i++){
	fputs ($fp, $sep.$nb_erreurs[$mouvement[$i]]);
	$sep=';';
}
fputs ($fp, "\n");
fclose ($fp);	
$fp = fopen ($path.'analyse.txt', "w+");
	for($i=0;$i<count($mouvement);$i++){
		if(count($bloc[$mouvement[$i]])!=0){
			for($j=0;$j<count($bloc[$mouvement[$i]]);$j++){
				fputs ($fp, $bloc[$mouvement[$i]][$j]);
			}
		}
	}
fclose ($fp);	

function charge_bande_gest($lignes,$fic)
{
	global $structure,$nb;
	
	// parcours des ligne
	$bases=array();
	for($i=0;$i<count($lignes);$i++)
	{		
		$base="";
		// on r�cup�re le code du mouvement
		if(substr($lignes[$i],40-1,1)=="4"){ // cas particulier des cartes comman�ant par 4
			$mvt=substr($lignes[$i],40-1,3);
		}else{
			$mvt=substr($lignes[$i],40-1,2);
		}


		// On concat�ne les champs de zone commune : zones du d�but
		for($j=0;$j<=9;$j++)
		{
			if($structure['ZC'][$j]['compare']=="1"){
				$base=$base.substr($lignes[$i],intval($structure['ZC'][$j]['position'])-1,intval($structure['ZC'][$j]['length']));
			}	
		}	


		// On y ajoute les champs clef du mouvement
		for($j=0;$j<count($structure[$mvt]);$j++)
		{
			if($structure[$mvt][$j]['compare']=="1"){
				$base=$base.substr($lignes[$i],intval($structure[$mvt][$j]['position'])-1,intval($structure[$mvt][$j]['length']));
			}	
		}	

		// On concat�ne les champs de zone commune : zones de fin
		for($j=10;$j<count($structure['ZC']);$j++)
		{
			if($structure['ZC'][$j]['compare']=="1"){
				$base=$base.substr($lignes[$i],intval($structure['ZC'][$j]['position'])-1,intval($structure['ZC'][$j]['length']));
			}	
		}	

		$bases[]=$base;
	}
	// le tableau est envoy� en valeur retour de la fonction	
	return $bases;
}

function charge_key_gest($lignes,$fic)
{
	global $structure,$nb,$mouvements,$dossiers;
	
	// parcours des lignes
	$keys=array();
	for($i=0;$i<count($lignes);$i++)
	{		
		if(array_search(substr($lignes[$i],23-1,15),$mouvements[$fic])===false){
						$mouvements[$fic][]=substr($lignes[$i],23-1,15);
		}
		if(array_search(substr($lignes[$i],0,37),$dossiers[$fic])===false){
						$dossiers[$fic][]=substr($lignes[$i],0,37);
		}
		$key="";
		// on r�cup�re le code du mouvement
		if(substr($lignes[$i],40-1,1)=="4"){ // cas particulier des cartes comman�ant par 4
			$mvt=substr($lignes[$i],40-1,3);
		}else{
			$mvt=substr($lignes[$i],40-1,2);
		}
		//echo $mvt;
		$nb[$fic][$mvt]++; // On incr�mente le nombre de mouvement

		// On concat�ne les champs de zone commune
		for($j=0;$j<count($structure['ZC']);$j++)
		{
			if($structure['ZC'][$j]['key']=="1"){
				$key=$key.substr($lignes[$i],intval($structure['ZC'][$j]['position'])-1,intval($structure['ZC'][$j]['length']));
			}	
		}	
		// On y ajoute les champs clef du mouvement
		for($j=0;$j<count($structure[$mvt]);$j++)
		{
			if($structure[$mvt][$j]['key']=="1"){
				$key=$key.substr($lignes[$i],intval($structure[$mvt][$j]['position'])-1,intval($structure[$mvt][$j]['length']));
			}	
		}	
		$keys[]=$key;
	}
	// le tableau est envoy� en valeur retour de la fonction	
	return $keys;
}
?>




