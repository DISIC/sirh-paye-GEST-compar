<?php
include 'vars.php'; // r�cup�re les variables
if($os_serveur=='unix'){
	header('Content-Type: text/html; charset=utf-8');
}else{	
	header('Content-Type: text/html; charset=ISO-8859-15');
}	
header("content-type: application/msexcel" );
header('Content-Disposition: attachment; filename="'.uniqid().'.xls"');
$id=$_COOKIE['id'];
?>
<!DOCTYPE html>
<html>
<body>
<?php

// Chargement des structure
$structure = json_decode($mouvements_structure,true);



if(!isset($_GET['share'])){
	$path='upload/'.$id.'/';
	$share='';
	$GET='';
}else{
	$path='share/';
	$share=$_GET['share'];
	$GET='?share='.$share;
}

$datas = explode("\n",file_get_contents($path.'infos'.$share.'.txt'));
$exact=$datas[2];
$all=$datas[3];;
$alone=$datas[4];

$analyse = file($path.'analyse'.$share.'.txt',FILE_SKIP_EMPTY_LINES);

echo '		<table border=1>'."\n";
echo '			<thead >'."\n";
echo '			<tr>'."\n";
echo '				<th>CODE</th><th>SI</th><th>CLEF_MVT</th><th>NOM_PRE</th><th>NUM_UTI</th><th>MVT</th><th>ANO</th>'."\n";
echo '			</tr>'."\n";
echo '			</thead >'."\n";
echo '			<tbody>'."\n";
for($i=0;$i<count($analyse);$i++){
	if(substr($analyse[$i],43,1)=="4"){
		$mvt=substr($analyse[$i],43,3);
	}else{
		$mvt=substr($analyse[$i],43,2);
	}
	$resultat=substr($analyse[$i],0,1); // R�cup�ration du code r�sultat
	$num_SI=substr($analyse[$i],2,1); // R�cup�ration du num�ro du SI (1 ou 2)
	$offset=($num_SI=='1' ? 1 : -1); // pour colorisation de l'erreur si diff�rence. On compare la donn�e avec la ligne suivante si SI 1 et pr�c�dente si SI 2

	echo '				<tr>'."\n";
	echo '					<td>'.substr($analyse[$i],0,3).'</td>'."\n";
	echo '					<td>'.$SI[substr($analyse[$i],1,2)].'</td>'."\n";
	echo '					<td>'.substr($analyse[$i],4,39).'</td>'."\n";
	echo '					<td>'.substr($analyse[$i],161-1+4,30).'</td>'."\n";
	echo '					<td>'.substr($analyse[$i],194-1+4,9).'</td>'."\n";
	echo '					<td>'.substr($analyse[$i],40-1+4,2).'</td>'."\n";
			
	$message='';
	$sep='';
	for($k=0;$k<count($structure[$mvt]);$k++){
		$v1=substr($analyse[$i],intval($structure[$mvt][$k]['position'])-1+4,intval($structure[$mvt][$k]['length']));
		$v2=substr($analyse[$i+$offset],intval($structure[$mvt][$k]['position'])-1+4,intval($structure[$mvt][$k]['length']));
		if($exact=='1'){ // Si mode exact
			if($resultat=='1' and $v1!=$v2){
				$message.=$sep.$structure[$mvt][$k]['field'].' '.$v1.' vs '.(($v2!='') ? '_NR' : $v2);
				$sep='/';
			}
		}else{ // Sinon on ne colorise que les champs � comparer
			if($resultat=='1' and $v1!=$v2 and $structure[$mvt][$k]['compare']=="1"){
				$message.=$sep.$structure[$mvt][$k]['field'].' '.$v1.' vs '.(($v2!='') ? '_NR' : $v2);
				$sep='/';
			}
		}
		switch ($resultat) {
			case '0':
					$message='OK';
				break;
			case '2':
					$message='Mvt '.$mvt.' absent '.(substr($analyse[$i],2,1)=='1' ? $SI['S2'] : $SI['S1']);
				break;
			case '3':
					$message='ligne en doublon dans '.$SI[substr($analyse[$i],1,2)];
				break;
		}	
	}	
	for($k=0;$k<count($structure['ZC']);$k++){
		if($structure['ZC'][$k]['key']=="0" && $resultat=='1'){
			if($exact=='1'){ // Si mode exact
				if($resultat=='1' and $v1!=$v2){
					$v1=substr($analyse[$i],intval($structure[$mvt][$k]['position'])-1+4,intval($structure[$mvt][$k]['length']));
					$v2=substr($analyse[$i+$offset],intval($structure[$mvt][$k]['position'])-1+4,intval($structure[$mvt][$k]['length']));
					$message.=$sep.$structure[$mvt][$k]['field'].' '.$v1.' vs '.(($v2!='') ? '_NR' : $v2);
					$sep='/';
				}
			}else{ // Sinon on ne colorise que les champs � comparer
				if($resultat=='1' and $v1!=$v2 and $structure['ZC'][$k]['compare']=="1"){
					$v1=substr($analyse[$i],intval($structure[$mvt][$k]['position'])-1+4,intval($structure[$mvt][$k]['length']));
					$v2=substr($analyse[$i+$offset],intval($structure[$mvt][$k]['position'])-1+4,intval($structure[$mvt][$k]['length']));
					$message.=$sep.$structure[$mvt][$k]['field'].' '.$v1.' vs '.(($v2!='') ? '_NR' : $v2);
					$sep='/';
				}
			}

		}
	}	
	echo '<td>'.$message.'</td>';
	echo '				</tr>'."\n";
	if($resultat=='1' ||$resultat=='3'){
		$i++;
	}
}
echo '			</tbody>'."\n";
echo '		</table>'."\n";

?>

</body>
</html>
